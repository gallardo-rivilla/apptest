# QuizPDFConverter v1.2 — Limpieza de pies/cabeceras + recuperación

Novedades:
- Elimina textos de pie/cabecera (dominio, "Página X", firmas, B3T… TAI, etc.), incluso cuando vienen con **letras separadas**.
- Mantiene recuperación de preguntas perdidas usando **SOLUCIONES**.

## Construcción del .exe
1. Python 3.9+ en Windows.
2. Doble clic a `build_exe.bat`.
3. Ejecutable en `dist\QuizPDFConverter.exe`.

## Uso
1. Selecciona **PDF(s)** o **Carpeta** de PDFs.
2. Selecciona **salida**.
3. Marca **JSON**, **CSV** o ambos.
4. Convierte. El log detallará recuperaciones y/o avisos.

Si detectas cualquier pie/cabecera nuevo que se cuele, dime un fragmento y lo añado a la lista de filtros.
