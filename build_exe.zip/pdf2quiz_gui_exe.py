#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quiz PDF Converter (GUI) v1.2 — Limpieza de pie de página/cabecera mejorada.
- Elimina dominios y firmas (p.ej., "www.theglobeformacion.com Página X").
- Detecta texto con letras separadas por espacios (P A B L O ... / B 3 T 6  t e s t ...).
- Recuperación de preguntas perdidas (v1.1).
"""
import os, sys, json, csv, re, threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

__VERSION__ = "1.2"

try:
    import PyPDF2
except Exception:
    root = tk.Tk(); root.withdraw()
    messagebox.showerror("Dependencia faltante",
        "Necesitas instalar PyPDF2 para ejecutar el .py.\n\npip install PyPDF2")
    raise

# ------------------ Utilidades de limpieza ------------------

def spaced_pattern(s: str) -> str:
    """Crea un patrón regex que acepta espacios arbitrarios entre letras/dígitos de s."""
    # escapa y añade \s* entre cada caracter
    parts = [re.escape(ch) for ch in s]
    return r'\s*'.join(parts)

NOISE_PATTERNS = [
    re.compile(r'www\.\s*theglobeformacion\.com(?:\s*Página\s*\d+)?', re.IGNORECASE),
    re.compile(r'Página\s*\d+', re.IGNORECASE),
    # Variantes con letras separadas (cabeceras/pies con B3T..., PABLO ARELLANO, TAI, TEST, etc.)
    re.compile(spaced_pattern("PABLO ARELLANO"), re.IGNORECASE),
    re.compile(spaced_pattern("PREPARACIÓN OPOSICIONES"), re.IGNORECASE),
    re.compile(spaced_pattern("TECNICOS AUXILIARES DE INFORMATICA"), re.IGNORECASE),
    re.compile(r'B\s*3\s*T\s*\d+\s*t\s*e\s*s\s*t[\s\S]{0,120}?(?:T\s*A\s*I|TAI)', re.IGNORECASE),
]

def strip_noise(text: str) -> str:
    s = text
    for rx in NOISE_PATTERNS:
        s = rx.sub(' ', s)
    # Colapsa espacios
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r' +\n', '\n', s)
    return s

# ------------------ Regex de parsing ------------------

REGEX_SOLUTIONS_BLOCK = re.compile(r'SOLUCIONES(.*)$', flags=re.IGNORECASE | re.DOTALL)
REGEX_SOLUTION_LINE   = re.compile(r'(\d{1,3})\.\s*([A-D])', flags=re.IGNORECASE)
REGEX_QSTART          = re.compile(r'(\d{1,3})\s*\.\s', flags=re.DOTALL)
REGEX_OPTIONS         = re.compile(
    r'(?:^|\s)a\)\s*(.*?)\s*b\)\s*(.*?)\s*c\)\s*(.*?)\s*d\)\s*(.*?)(?=$|\n\d{1,3}\s*\.\s|SOLUCIONES)',
    flags=re.DOTALL | re.IGNORECASE
)

def extract_text_pages(pdf_path: Path):
    pages = []
    with open(pdf_path, "rb") as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            pages.append((page.extract_text() or "") + "\n")
    return pages

def normalize_text(s: str) -> str:
    s = s.replace('\xa0', ' ')
    s = re.sub(r'\r', '', s)
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r' +\n', '\n', s)
    return s

def clean_seg(s: str) -> str:
    s = strip_noise(s)
    s = re.sub(r'\s*\n\s*', ' ', s)
    s = re.sub(r'\s{2,}', ' ', s)
    return s.strip(' -:')

def parse_solutions(full_text: str):
    m = REGEX_SOLUTIONS_BLOCK.search(full_text)
    answers = {}
    if m:
        for mm in REGEX_SOLUTION_LINE.finditer(m.group(1)):
            answers[int(mm.group(1))] = mm.group(2).upper()
    return answers, (m.start() if m else -1)

def parse_blocks(body_text: str):
    s = body_text
    idxs = [m.start() for m in REGEX_QSTART.finditer(s)]
    idxs.append(len(s))
    found = {}
    for i in range(len(idxs)-1):
        seg = s[idxs[i]:idxs[i+1]]
        mnum = re.match(r'(\d{1,3})\s*\.\s(.*)', seg, flags=re.DOTALL)
        if not mnum: 
            continue
        num = int(mnum.group(1))
        tail = mnum.group(2)
        mopt = REGEX_OPTIONS.search(tail)
        if not mopt:
            continue
        stem = clean_seg(tail[:mopt.start()])
        A,B,C,D = [clean_seg(x) for x in mopt.groups()]
        found[num] = (stem, A,B,C,D)
    return found

def recover_missing(full_text: str, body_text: str, initial_map: dict, answers_map: dict, log_cb):
    if not answers_map:
        return initial_map, []
    max_n = max(answers_map)
    missing = sorted(set(answers_map.keys()) - set(initial_map.keys()))
    recovered = []
    if not missing:
        return initial_map, recovered

    for n in missing:
        pat_n = re.compile(rf'{n}\s*\.\s', flags=re.DOTALL)
        pat_np1 = re.compile(rf'{n+1}\s*\.\s', flags=re.DOTALL)
        m_start = pat_n.search(body_text)
        m_end = pat_np1.search(body_text)
        if not m_start:
            pat_prev = re.compile(rf'{n-1}\s*\.\s', flags=re.DOTALL) if n>1 else None
            m_prev = pat_prev.search(body_text) if pat_prev else None
            if m_prev:
                prev_tail = body_text[m_prev.end():]
                idx_d = prev_tail.lower().find('d)')
                start_idx = m_prev.end() + idx_d + 2 if idx_d!=-1 else m_prev.end()
            else:
                start_idx = 0
        else:
            start_idx = m_start.end()

        end_idx = m_end.start() if m_end else len(body_text)
        region = strip_noise(body_text[start_idx:end_idx])

        mopt = REGEX_OPTIONS.search(region)
        if not mopt:
            continue
        stem = clean_seg(region[:mopt.start()])
        A,B,C,D = [clean_seg(x) for x in mopt.groups()]
        initial_map[n] = (stem, A,B,C,D)
        recovered.append(n)
        if log_cb:
            log_cb(f"[RECUPERADA] #{n}: región entre #{n-1} y #{n+1}")
    return initial_map, recovered

def parse_pdf_to_items_with_recovery(pdf_path: Path, log_cb=None):
    pages = extract_text_pages(pdf_path)
    # Limpia ruido por página para minimizar contaminación dentro de opciones
    pages_clean = [ strip_noise(normalize_text(p)) for p in pages ]
    full_norm = "".join(pages_clean)
    answers_map, sol_pos = parse_solutions(full_norm)
    body_text = full_norm[:sol_pos] if sol_pos != -1 else full_norm

    found = parse_blocks(body_text)
    found2, recovered = recover_missing(full_norm, body_text, found, answers_map, log_cb)

    nums = sorted(found2.keys() or answers_map.keys())
    items = []
    for n in nums:
        if n not in found2:
            if log_cb: log_cb(f"[AVISO] #{n} sin bloque de opciones; se ignora.")
            continue
        stem, A,B,C,D = found2[n]
        items.append({
            "id": n,
            "question": stem,
            "options": [{"key":"A","text":A},{"key":"B","text":B},{"key":"C","text":C},{"key":"D","text":D}],
            "answer": answers_map.get(n, "")
        })
    return items, recovered, len(answers_map)

def write_json(items, out_json: Path):
    out_json.parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)

def write_csv(items, out_csv: Path):
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    with open(out_csv, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id","question","A","B","C","D","answer"])
        for it in items:
            w.writerow([
                it.get("id",""),
                it.get("question",""),
                it["options"][0]["text"] if it.get("options") else "",
                it["options"][1]["text"] if it.get("options") else "",
                it["options"][2]["text"] if it.get("options") else "",
                it["options"][3]["text"] if it.get("options") else "",
                it.get("answer","") or ""
            ])

# ------------------ GUI ------------------
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Quiz PDF Converter v{__VERSION__}")
        self.geometry("780x560")
        self.minsize(740, 520)

        self.pdf_files = []
        self.in_folder = None
        self.out_folder = None
        self.export_json = tk.BooleanVar(value=True)
        self.export_csv  = tk.BooleanVar(value=True)

        self.create_widgets()

    def create_widgets(self):
        pad = {"padx":10, "pady":6}
        frm = ttk.Frame(self); frm.pack(fill="both", expand=True)

        ttk.Label(frm, text="1) Selecciona PDFs o una carpeta con PDFs").grid(row=0, column=0, columnspan=5, sticky="w", **pad)
        ttk.Button(frm, text="Elegir PDF(s)…", command=self.choose_files).grid(row=1, column=0, sticky="w", **pad)
        ttk.Button(frm, text="Elegir carpeta…", command=self.choose_folder).grid(row=1, column=1, sticky="w", **pad)
        self.lbl_input = ttk.Label(frm, text="Sin seleccionar"); self.lbl_input.grid(row=1, column=2, columnspan=3, sticky="w", **pad)

        ttk.Label(frm, text="2) Selecciona carpeta de salida").grid(row=2, column=0, columnspan=5, sticky="w", **pad)
        ttk.Button(frm, text="Elegir salida…", command=self.choose_out).grid(row=3, column=0, sticky="w", **pad)
        self.lbl_out = ttk.Label(frm, text="Sin seleccionar"); self.lbl_out.grid(row=3, column=1, columnspan=4, sticky="w", **pad)

        ttk.Label(frm, text="3) Formato de exportación").grid(row=4, column=0, columnspan=5, sticky="w", **pad)
        ttk.Checkbutton(frm, text="JSON", variable=self.export_json, command=self.update_run_state).grid(row=5, column=0, sticky="w", **pad)
        ttk.Checkbutton(frm, text="CSV",  variable=self.export_csv,  command=self.update_run_state).grid(row=5, column=1, sticky="w", **pad)

        self.btn_run = ttk.Button(frm, text="Convertir", command=self.run_convert, state="disabled")
        self.btn_run.grid(row=6, column=0, sticky="w", **pad)

        self.pb = ttk.Progressbar(frm, orient="horizontal", mode="determinate", length=360)
        self.pb.grid(row=6, column=1, columnspan=2, sticky="we", **pad)

        self.lbl_status = ttk.Label(frm, text="Listo"); self.lbl_status.grid(row=6, column=3, sticky="e", **pad)

        ttk.Label(frm, text="Salida").grid(row=7, column=0, columnspan=5, sticky="w", **pad)
        self.txt = tk.Text(frm, height=14, wrap="word"); self.txt.grid(row=8, column=0, columnspan=5, sticky="nsew", padx=10, pady=(0,10))

        frm.rowconfigure(8, weight=1); frm.columnconfigure(2, weight=1)

    def choose_files(self):
        files = filedialog.askopenfilenames(title="Selecciona PDF(s)", filetypes=[("PDF", "*.pdf")])
        if files:
            self.pdf_files = list(files); self.in_folder = None
            self.update_input_label(); self.update_run_state()

    def choose_folder(self):
        folder = filedialog.askdirectory(title="Carpeta con PDFs")
        if folder:
            self.in_folder = folder; self.pdf_files = []
            self.update_input_label(); self.update_run_state()

    def choose_out(self):
        folder = filedialog.askdirectory(title="Carpeta de salida")
        if folder:
            self.out_folder = folder; self.lbl_out.config(text=folder); self.update_run_state()

    def update_input_label(self):
        if self.pdf_files:
            self.lbl_input.config(text=f"{len(self.pdf_files)} PDF(s) seleccionados")
        elif self.in_folder:
            self.lbl_input.config(text=f"Carpeta: {self.in_folder}")
        else:
            self.lbl_input.config(text="Sin seleccionar")

    def update_run_state(self):
        ok_in = bool(self.pdf_files or self.in_folder)
        ok_out = bool(self.out_folder)
        ok_fmt = self.export_json.get() or self.export_csv.get()
        self.btn_run.config(state="normal" if ok_in and ok_out and ok_fmt else "disabled")

    def log(self, msg):
        self.txt.insert("end", msg + "\n"); self.txt.see("end"); self.update_idletasks()

    def run_convert(self):
        if not (self.export_json.get() or self.export_csv.get()):
            messagebox.showwarning("Formato", "Selecciona al menos JSON o CSV."); return
        if self.in_folder:
            pdfs = sorted(Path(self.in_folder).glob("*.pdf"))
        else:
            pdfs = [Path(p) for p in self.pdf_files]
        if not pdfs:
            messagebox.showwarning("Nada que hacer", "No se encontraron PDFs."); return
        outdir = Path(self.out_folder); outdir.mkdir(parents=True, exist_ok=True)
        threading.Thread(target=self._convert_thread, args=(pdfs, outdir, self.export_json.get(), self.export_csv.get()), daemon=True).start()

    def _convert_thread(self, pdfs, outdir: Path, do_json: bool, do_csv: bool):
        self.pb.config(maximum=len(pdfs), value=0); self.lbl_status.config(text="Procesando…")
        total_q = 0; ok_files = 0
        for i, pdf in enumerate(pdfs, start=1):
            try:
                self.log(f"→ {pdf.name}")
                items, recovered, expected = parse_pdf_to_items_with_recovery(pdf, self.log)
                total_q += len(items); ok_files += 1
                rec_msg = f" · recuperadas: {len(recovered)}" if recovered else ""
                self.log(f"[OK] {pdf.name}: {len(items)}/{expected} preguntas{rec_msg}")
                stem = pdf.stem
                if do_json:
                    write_json(items, outdir / f"{stem}_quiz.json")
                if do_csv:
                    write_csv(items,  outdir / f"{stem}_quiz.csv")
            except Exception as e:
                self.log(f"[ERROR] {pdf.name}: {e}")
            self.pb.config(value=i); self.lbl_status.config(text=f"{i}/{len(pdfs)}"); self.update_idletasks()
        self.log(f"\nHecho. Archivos ok: {ok_files}/{len(pdfs)} · Total preguntas: {total_q}")
        self.lbl_status.config(text="Completado")

if __name__ == "__main__":
    app = App()
    app.mainloop()
